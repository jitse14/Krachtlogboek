-- Athlevon update v9 (veilig om opnieuw te draaien).
-- Nieuw: toestemming om al je gedane trainingen te zien, en om je agenda (planning) te zien.

-- 1. Nieuwe toestemmingen: trainingen zien en agenda zien
create or replace function kl_perm_norm(p jsonb) returns jsonb language sql immutable as $$
  select jsonb_build_object(
    'plan', coalesce((p->>'plan')::boolean, false), 'schemas', coalesce((p->>'schemas')::boolean, false),
    'food', coalesce((p->>'food')::boolean, false), 'results', coalesce((p->>'results')::boolean, false),
    'sessions', coalesce((p->>'sessions')::boolean, false), 'agenda', coalesce((p->>'agenda')::boolean, false),
    'progress', coalesce((p->>'progress')::boolean, false), 'together', coalesce((p->>'together')::boolean, false),
    'direct', coalesce((p->>'direct')::boolean, false)) $$;
revoke execute on function kl_perm_norm(jsonb) from public, anon, authenticated;

-- 2. Meekijken: alleen wat de ander heeft toegestaan
--    voortgang  = trainingen, records, gewicht, voeding en planning
--    trainingen = alleen gedane trainingen en oefeningen
--    agenda     = alleen de planning (vanaf 70 dagen terug)
create or replace function kl_help_progress(p_code text, p_profile text, p_pin text, p_link bigint) returns jsonb
language plpgsql security definer set search_path = public as $$
declare l kl_links%rowtype; since text := to_char(now() - interval '70 days', 'YYYY-MM-DD');
  pr boolean; se boolean; ag boolean;
begin perform kl_auth(p_code, p_profile, p_pin);
  select * into l from kl_links where id = p_link and helper = p_profile and status = 'active';
  if not found then raise exception 'geen toestemming'; end if;
  pr := coalesce((l.perms->>'progress')::boolean, false);
  se := pr or coalesce((l.perms->>'sessions')::boolean, false);
  ag := pr or coalesce((l.perms->>'agenda')::boolean, false);
  if not (pr or se or ag) then raise exception 'geen toestemming'; end if;
  return (select coalesce(jsonb_object_agg(c.coll, c.docs), '{}') from (
    select d.coll, jsonb_object_agg(d.id, d.data) docs from kl_docs d
    where d.profile_id = l.owner and (
      (se and d.coll in ('sessions', 'exercises', 'archive'))
      or (pr and d.coll = 'weights')
      or (pr and d.coll = 'meta' and d.id = 'body')
      or (pr and d.coll = 'foodlog' and coalesce(d.data->>'date', '') >= since)
      or (ag and d.coll in ('plan', 'routines') and (d.coll = 'routines' or coalesce(d.data->>'date', '') >= since)))
    group by d.coll) c);
end $$;
grant execute on function kl_help_progress(text, text, text, bigint) to anon, authenticated;
